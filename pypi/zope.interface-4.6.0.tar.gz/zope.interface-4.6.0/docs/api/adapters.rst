==================
 Adapter Registry
==================

Usage of the adapter registry is documented in :ref:`adapter-registry`.


The adapter registry's API is defined by
:class:`zope.interface.interfaces.IAdapterRegistry`:

.. autointerface:: zope.interface.adapter.IAdapterRegistry
   :members:
   :member-order: bysource
