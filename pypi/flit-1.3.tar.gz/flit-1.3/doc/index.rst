Flit |version|
==============

.. raw:: html

   <img src="_static/flit_logo_nobg_cropped.svg" width="200px" style="float: right"/>

.. include:: ../README.rst

Documentation contents
----------------------

.. toctree::
   :maxdepth: 2

   pyproject_toml
   cmdline
   upload
   reproducible
   history

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`

