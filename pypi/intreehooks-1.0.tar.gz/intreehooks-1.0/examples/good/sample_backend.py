# A proper backend needs more hooks than this - this is just to test resolving
# it through intreehooks.

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    return 'itsalie'
