from __future__ import absolute_import

from corsheaders.models import AbstractCorsModel


class CorsModel(AbstractCorsModel):
    pass
