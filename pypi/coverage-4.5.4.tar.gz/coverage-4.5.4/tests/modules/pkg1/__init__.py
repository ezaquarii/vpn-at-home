# A simple package for testing with.
print("pkg1.__init__: %s" % (__name__,))
