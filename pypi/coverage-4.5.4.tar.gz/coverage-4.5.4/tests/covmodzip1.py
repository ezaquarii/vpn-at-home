# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://bitbucket.org/ned/coveragepy/src/default/NOTICE.txt

# Module-level docstrings are counted differently in different versions of Python,
# so don't add one here.
# pylint: disable=missing-docstring

# covmodzip.py: for putting into a zip file.
j = 1
j += 1
