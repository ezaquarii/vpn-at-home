in_with_stub_both = 5
in_with_stub_python = 8
