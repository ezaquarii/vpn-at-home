popen_spawn - use pexpect with a piped subprocess
=================================================

.. automodule:: pexpect.popen_spawn

PopenSpawn class
----------------

.. autoclass:: PopenSpawn

   .. automethod:: __init__
   .. automethod:: send
   .. automethod:: sendline
   .. automethod:: write
   .. automethod:: writelines
   .. automethod:: kill
   .. automethod:: sendeof
   .. automethod:: wait
   
   .. method:: expect
               expect_exact
               expect_list

      As :class:`pexpect.spawn`.
