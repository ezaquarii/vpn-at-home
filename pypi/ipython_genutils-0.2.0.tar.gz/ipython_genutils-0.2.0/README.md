# IPython vestigial utilities

This package shouldn't exist.
It contains some common utilities shared by Jupyter and IPython projects during The Big Split™.
As soon as possible, those packages will remove their dependency on this,
and this repo will go away.

No functionality should be added to this repository,
and no packages outside IPython/Jupyter should depend on it.
