
.. _base.Asn1Type:

.. |ASN.1| replace:: Asn1Type

|ASN.1| type
------------

.. autoclass:: pyasn1.type.base.Asn1Type(tagSet=TagSet(), subtypeSpec=ConstraintsIntersection())
   :members: isSameTypeWith, isSuperTypeOf, tagSet, effectiveTagSet, tagMap, subtypeSpec
