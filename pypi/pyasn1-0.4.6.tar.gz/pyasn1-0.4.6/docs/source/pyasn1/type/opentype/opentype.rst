
.. _opentype.OpenType:

.. |OpenType| replace:: OpenType

|OpenType|
-----------

.. autoclass:: pyasn1.type.opentype.OpenType
   :members:

More information on open type use can be found :ref:`here <type.opentype>`.