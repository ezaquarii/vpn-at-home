Installation
------------

Install sphinx::

    sudo pip install sphinx
